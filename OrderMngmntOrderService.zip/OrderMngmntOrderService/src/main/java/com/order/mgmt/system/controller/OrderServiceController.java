package com.order.mgmt.system.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.order.mgmt.system.model.Order;
import com.order.mgmt.system.model.OrderItem;
import com.order.mgmt.system.repository.OrderRepository;

@RestController
@RequestMapping("/orderservice")
public class OrderServiceController {
	
	@Autowired
	OrderRepository orderRepository;
	
	@PersistenceContext
    private EntityManager em;
	
	@PostMapping("/createOrder")
    public ResponseEntity<String> createOrder(@Valid @RequestBody Order order) {
		System.out.println(order);
		orderRepository.save(order);
        return ResponseEntity.ok("Order inserted");
    }
	
	@PostMapping("/createOrderItem/{id}")
    public ResponseEntity<String> createOrderItem(@Valid @RequestBody OrderItem orderItem, @PathVariable("id") String id) {
		Optional<Order> order = orderRepository.findById(Integer.parseInt(id));
		List<OrderItem> orderItemFind = order.get().getOrderitems();
		orderItemFind.add(orderItem);
		order.get().setOrderitems(orderItemFind);
		orderRepository.save(order.get());
        return ResponseEntity.ok("OrderItem inserted");
    }
	
	@GetMapping("/getOrder")
    public ResponseEntity<List<Order>> getOrder() {
		List<Order> order = orderRepository.findAll();
		return new ResponseEntity<>(order,HttpStatus.OK);
    }
	
	@GetMapping("/getOrderItem")
	public ResponseEntity<List<OrderItem>> getOrderItem() {
		List<Order> orders = orderRepository.findAll();
		List<OrderItem> totalOrderItems = new ArrayList<OrderItem>();
		for (Order order : orders) {
			List<OrderItem> orderItems = order.getOrderitems();
			totalOrderItems.addAll(orderItems);
		}
		return new ResponseEntity<>(totalOrderItems,HttpStatus.OK);
    } 
	
	@GetMapping("/getOrderItem/{productCode}")
	public ResponseEntity<OrderItem> getOrderItem(@PathVariable("productCode") String productCode) {
		List<Order> orders = orderRepository.findAll();
		OrderItem orderItem = new OrderItem();
		for (Order order : orders) {
			List<OrderItem> orderItems = order.getOrderitems();
			orderItem = orderItems.stream()
					  .filter(orderItemfind -> productCode.equals(orderItemfind.getProductCode()))
					  .findAny()
					  .orElse(null);
			return new ResponseEntity<>(orderItem,HttpStatus.OK);
		}
		return new ResponseEntity<>(orderItem,HttpStatus.OK);
	}
}
