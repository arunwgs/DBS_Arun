package com.order.mgmt.system.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.order.mgmt.system.model.OrderItem;
import com.order.mgmt.system.repository.OrderItemRepository;

@RestController
@RequestMapping(value= "/feign")
public class OrderItemServiceController {
	@Autowired
	OrderItemRepository orderItemRepository;
	
	@Autowired
	OrderItemClient orderItemClient;
	
	@PostMapping("/createOrderItem/{id}")
    public ResponseEntity<String> createOrder(@Valid @RequestBody OrderItem orderItem, @PathVariable("id") String id) {
		// Fetching the greetings salutation for the given locale. 
		// Data is fetched from thr greetings microservice hosted on port no. - 8181
		orderItemClient.createOrderItem(orderItem, id);
        return ResponseEntity.ok("OrderItem inserted for Order Id :: "+ id);
    }
	
	@GetMapping("/getOrderItem")
    public ResponseEntity<List<OrderItem>> getOrderItem() {
		// Fetching the greetings salutation for the given locale. 
		// Data is fetched from thr greetings microservice hosted on port no. - 8181
		List<OrderItem> orderItems = orderItemClient.getOrderItem();
		return new ResponseEntity<>(orderItems,HttpStatus.OK);
    }
	
	@GetMapping(value="/getOrderItem/{productCode}", produces= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<OrderItem> getOrderItem(@PathVariable(name= "productCode") String productCode) {

		// Fetching the greetings salutation for the given locale. 
		// Data is fetched from thr greetings microservice hosted on port no. - 8181
		OrderItem orderItem = orderItemClient.getOrderItem(productCode);
		// Sending the response
		return new ResponseEntity<>(orderItem, HttpStatus.OK);
	}
}
