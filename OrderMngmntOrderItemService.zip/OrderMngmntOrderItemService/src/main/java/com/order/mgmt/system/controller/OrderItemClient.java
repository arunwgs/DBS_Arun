package com.order.mgmt.system.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.order.mgmt.system.model.OrderItem;

@FeignClient(name= "orderservice")
public interface OrderItemClient {
	@GetMapping(value= "/orderservice/getOrderItem/{productCode}")
	public OrderItem getOrderItem(@PathVariable(name= "productCode") String langCode);
	
	@GetMapping(value= "/orderservice/getOrderItem")
	public List<OrderItem> getOrderItem();
	
	@PostMapping(value= "/orderservice/createOrderItem/{id}")
	public void createOrderItem(@Valid @RequestBody OrderItem orderItem, @PathVariable("id") String id);
}
