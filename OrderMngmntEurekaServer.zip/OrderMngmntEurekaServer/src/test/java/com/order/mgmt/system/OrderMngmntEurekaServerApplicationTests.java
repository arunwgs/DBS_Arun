package com.order.mgmt.system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderMngmntEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
